﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myGrid
{
    public class GridInList
    {
        public string HeaderCellText { get; set; }
        public List<string> ValueCells { get; set; }
    }
}
