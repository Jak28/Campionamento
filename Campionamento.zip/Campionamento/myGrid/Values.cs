﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myGrid
{
    public class Values
    {
        public double Min { get; set; }
        public double Max { get; set; }
        public double Media { get; set; }
        public double Var { get; set; }
        public string HeaderCell { get; set; }
    }
}
